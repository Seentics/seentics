<?php
/**
 * WooCommerce events. Names and properties follow Seentics' revenue docs:
 * `purchase` { value, currency, order_id, product_name, user_type, items[] }.
 */

defined( 'ABSPATH' ) || exit;

function seentics_wc_enabled() {
	$o = seentics_options();
	return ! empty( $o['woocommerce'] ) && function_exists( 'WC' ) && seentics_should_track();
}

/** Money as a plain number, two decimals: `49.99`, not "$49.99". */
function seentics_money( $amount ) {
	return round( (float) $amount, 2 );
}

/** Properties for one product. */
function seentics_wc_product_props( $product, $qty = 1 ) {
	if ( ! $product instanceof WC_Product ) {
		return array();
	}
	return array(
		'item_id'      => $product->get_id(),
		'product_name' => wp_strip_all_tags( $product->get_name() ),
		'sku'          => (string) $product->get_sku(),
		'value'        => seentics_money( (float) wc_get_price_to_display( $product ) * max( 1, (int) $qty ) ),
		'currency'     => get_woocommerce_currency(),
		'qty'          => max( 1, (int) $qty ),
	);
}

/** Is this the first paid order from this customer? Guests are matched by billing email. */
function seentics_wc_user_type( WC_Order $order ) {
	$args = array(
		'limit'   => 1,
		'return'  => 'ids',
		'status'  => array( 'wc-processing', 'wc-completed', 'wc-on-hold' ),
		'exclude' => array( $order->get_id() ),
		// Only orders placed before this one, so reloading the page later gives the same answer.
		'date_created' => '<' . ( $order->get_date_created() ? $order->get_date_created()->getTimestamp() : time() ),
	);
	if ( $order->get_customer_id() ) {
		$args['customer_id'] = $order->get_customer_id();
	} elseif ( $order->get_billing_email() ) {
		$args['billing_email'] = $order->get_billing_email();
	} else {
		return 'new';
	}
	return wc_get_orders( $args ) ? 'returning' : 'new';
}

/** The order-received page: the purchase. */
add_action(
	'woocommerce_thankyou',
	function ( $order_id ) {
		if ( ! seentics_wc_enabled() ) {
			return;
		}
		$order = wc_get_order( $order_id );
		if ( ! $order instanceof WC_Order || $order->has_status( array( 'failed', 'cancelled' ) ) ) {
			return;
		}

		$items = array();
		foreach ( $order->get_items() as $item ) {
			$qty     = max( 1, (int) $item->get_quantity() );
			$product = $item->get_product();
			$items[] = array(
				'name'  => wp_strip_all_tags( $item->get_name() ),
				'sku'   => $product ? (string) $product->get_sku() : '',
				'qty'   => $qty,
				// Unit price after discounts, before tax.
				'price' => seentics_money( (float) $item->get_total() / $qty ),
			);
		}

		seentics_print_events(
			array(
				seentics_event_js(
					'purchase',
					array(
						// Order total: what the customer paid, tax and shipping included.
						'value'        => seentics_money( $order->get_total() ),
						'currency'     => $order->get_currency(),
						// Seentics counts one order per id, so reloading this page is harmless.
						'order_id'     => (string) $order->get_order_number(),
						'product_name' => $items ? $items[0]['name'] : '',
						'user_type'    => seentics_wc_user_type( $order ),
						'items'        => $items,
					)
				),
			)
		);
	}
);

/** The checkout page (classic or block), but not the confirmation that follows it. */
add_action(
	'wp_footer',
	function () {
		if ( ! seentics_wc_enabled() || ! function_exists( 'is_checkout' ) || ! is_checkout() || is_order_received_page() ) {
			return;
		}
		$cart = WC()->cart;
		if ( ! $cart || $cart->is_empty() ) {
			return;
		}
		seentics_print_events(
			array(
				seentics_event_js(
					'begin_checkout',
					array(
						'value'    => seentics_money( $cart->get_total( 'edit' ) ),
						'currency' => get_woocommerce_currency(),
						'qty'      => (int) $cart->get_cart_contents_count(),
					)
				),
			)
		);
	}
);

/** A product page. */
add_action(
	'wp_footer',
	function () {
		if ( ! seentics_wc_enabled() || ! function_exists( 'is_product' ) || ! is_product() ) {
			return;
		}
		$props = seentics_wc_product_props( wc_get_product( get_queried_object_id() ) );
		if ( $props ) {
			seentics_print_events( array( seentics_event_js( 'view_item', $props ) ) );
		}
	}
);

/**
 * Add to cart.
 *
 * A normal form post reloads the page, so the add is remembered in the WooCommerce
 * session and reported by the next page. The classic AJAX button (archive pages) and the
 * block cart never reload, so the first is reported from the browser instead.
 */
add_action(
	'woocommerce_add_to_cart',
	function ( $cart_item_key, $product_id, $quantity, $variation_id ) {
		if ( ! function_exists( 'WC' ) || ! WC()->session ) {
			return;
		}
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( wp_doing_ajax() || isset( $_GET['wc-ajax'] ) ) {
			return;
		}
		$pending   = WC()->session->get( 'seentics_adds', array() );
		$pending   = is_array( $pending ) ? $pending : array();
		$pending[] = array(
			'id'  => (int) ( $variation_id ? $variation_id : $product_id ),
			'qty' => max( 1, (int) $quantity ),
		);
		WC()->session->set( 'seentics_adds', array_slice( $pending, -10 ) );
		if ( ! WC()->session->has_session() ) {
			WC()->session->set_customer_session_cookie( true );
		}
	},
	10,
	4
);

add_action(
	'wp_footer',
	function () {
		if ( ! seentics_wc_enabled() || ! WC()->session ) {
			return;
		}
		$pending = WC()->session->get( 'seentics_adds' );
		if ( empty( $pending ) || ! is_array( $pending ) ) {
			return;
		}
		WC()->session->set( 'seentics_adds', null );
		$calls = array();
		foreach ( $pending as $add ) {
			$props = seentics_wc_product_props( wc_get_product( (int) $add['id'] ), (int) $add['qty'] );
			if ( $props ) {
				$calls[] = seentics_event_js( 'add_to_cart', $props );
			}
		}
		seentics_print_events( $calls );
	}
);

/** The AJAX add-to-cart button: its own event, with what the button knows. */
add_action(
	'wp_footer',
	function () {
		if ( ! seentics_wc_enabled() ) {
			return;
		}
		$js = seentics_waiter_js() . <<<'JS'
(function(){
	if(!window.jQuery){return;}
	window.jQuery(document.body).on('added_to_cart',function(e,fragments,hash,$btn){
		var d=$btn&&$btn.data?$btn.data():{};
		seenticsRun(function(s){s.track('add_to_cart',{item_id:d.product_id||null,sku:d.product_sku||'',qty:parseInt(d.quantity,10)||1});});
	});
})();
JS;
		wp_print_inline_script_tag( $js, array( 'id' => 'seentics-ajax-cart' ) );
	}
);
