<?php
/**
 * The tracker script, and the helpers other parts use to send events from the page.
 */

defined( 'ABSPATH' ) || exit;

/** Should this request load the tracker? */
function seentics_should_track() {
	$o = seentics_options();
	if ( ! seentics_is_valid_website_id( $o['website_id'] ) ) {
		return false;
	}
	if ( is_admin() || is_customize_preview() || is_feed() || is_robots() ) {
		return false;
	}
	if ( empty( $o['track_admins'] ) && current_user_can( 'manage_options' ) ) {
		return false;
	}
	return (bool) apply_filters( 'seentics_should_track', true );
}

add_action(
	'wp_enqueue_scripts',
	function () {
		if ( ! seentics_should_track() ) {
			return;
		}
		$o = seentics_options();
		// `null` version: no `?ver=` on a file the Seentics host already versions and caches.
		wp_enqueue_script( 'seentics', $o['script_url'], array(), null, false ); // phpcs:ignore WordPress.WP.EnqueuedResourceParameters.MissingVersion
	}
);

/**
 * The tracker reads its own <script> element for its settings, so the tag has to carry
 * them — and `defer`, because it needs the element to exist when it runs.
 */
add_filter(
	'script_loader_tag',
	function ( $tag, $handle, $src ) {
		if ( 'seentics' !== $handle ) {
			return $tag;
		}
		$o = seentics_options();
		return sprintf(
			"<script id=\"seentics-js\" defer data-website-id=\"%s\" src=\"%s\"></script>\n",
			esc_attr( $o['website_id'] ),
			esc_url( $src )
		);
	},
	10,
	3
);

/**
 * JavaScript that sends one event once the tracker has loaded.
 *
 * The tracker is `defer`red, so a call made while the page is still being parsed would
 * find no `seentics` object. This waits up to ten seconds for it, then gives up quietly
 * (an ad blocker is the usual reason it never arrives).
 *
 * JSON is encoded with the HEX flags so a product named `</script><script>…` cannot end
 * the tag it is printed in.
 */
function seentics_event_js( $name, array $props = array() ) {
	$flags = JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT;
	return sprintf(
		'seenticsRun(function(s){s.track(%s,%s);});',
		wp_json_encode( (string) $name, $flags ),
		wp_json_encode( (object) $props, $flags )
	);
}

/** Defines `seenticsRun(fn)`: run fn(seentics) once the tracker is there. Safe to include twice. */
function seentics_waiter_js() {
	return '(function(w){w.seenticsRun=w.seenticsRun||function(f){var n=0;(function t(){if(w.seentics&&typeof w.seentics.track==="function"){try{f(w.seentics);}catch(e){}return;}if(++n<100){setTimeout(t,100);}})();};})(window);';
}

/** Print one or more event calls, preceded by the small waiter they need. */
function seentics_print_events( array $js_calls ) {
	if ( ! $js_calls || ! seentics_should_track() ) {
		return;
	}
	wp_print_inline_script_tag( seentics_waiter_js() . implode( '', $js_calls ), array( 'id' => 'seentics-events' ) );
}
