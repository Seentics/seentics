<?php
/**
 * Options and the Settings → Seentics page.
 */

defined( 'ABSPATH' ) || exit;

/** The saved options, with defaults filled in. */
function seentics_options() {
	$saved = get_option( 'seentics_options', array() );
	return array_merge(
		array(
			'website_id'   => '',
			'script_url'   => SEENTICS_DEFAULT_SCRIPT_URL,
			'track_admins' => 0,
			'woocommerce'  => 1,
		),
		is_array( $saved ) ? $saved : array()
	);
}

/** Website ids are UUIDs (Settings → Tracking in Seentics). Anything else is refused, never echoed into a page. */
function seentics_is_valid_website_id( $value ) {
	return is_string( $value ) && 1 === preg_match( '/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i', $value );
}

function seentics_sanitize_options( $input ) {
	$input   = is_array( $input ) ? $input : array();
	$current = seentics_options();
	$out     = array();

	$id = isset( $input['website_id'] ) ? strtolower( trim( sanitize_text_field( wp_unslash( $input['website_id'] ) ) ) ) : '';
	if ( '' === $id || seentics_is_valid_website_id( $id ) ) {
		$out['website_id'] = $id;
	} else {
		$out['website_id'] = $current['website_id'];
		add_settings_error( 'seentics_options', 'seentics_bad_id', __( 'That is not a Seentics website ID. Copy it from Settings → Tracking in Seentics; it looks like 123e4567-e89b-12d3-a456-426614174000.', 'seentics' ) );
	}

	$url = isset( $input['script_url'] ) ? esc_url_raw( trim( wp_unslash( $input['script_url'] ) ), array( 'https' ) ) : '';
	$out['script_url'] = '' === $url ? SEENTICS_DEFAULT_SCRIPT_URL : $url;

	$out['track_admins'] = empty( $input['track_admins'] ) ? 0 : 1;
	$out['woocommerce']  = empty( $input['woocommerce'] ) ? 0 : 1;

	return $out;
}

add_action(
	'admin_init',
	function () {
		register_setting(
			'seentics',
			'seentics_options',
			array(
				'type'              => 'array',
				'sanitize_callback' => 'seentics_sanitize_options',
				'default'           => array(),
			)
		);
	}
);

add_action(
	'admin_menu',
	function () {
		add_options_page( __( 'Seentics', 'seentics' ), __( 'Seentics', 'seentics' ), 'manage_options', 'seentics', 'seentics_render_settings' );
	}
);

function seentics_render_settings() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	$o = seentics_options();
	?>
	<div class="wrap">
		<h1><?php esc_html_e( 'Seentics', 'seentics' ); ?></h1>
		<?php if ( '' === $o['website_id'] ) : ?>
			<div class="notice notice-warning inline"><p><?php esc_html_e( 'Nothing is tracked until you add your website ID.', 'seentics' ); ?></p></div>
		<?php endif; ?>
		<form method="post" action="options.php">
			<?php settings_fields( 'seentics' ); ?>
			<table class="form-table" role="presentation">
				<tr>
					<th scope="row"><label for="seentics_website_id"><?php esc_html_e( 'Website ID', 'seentics' ); ?></label></th>
					<td>
						<input name="seentics_options[website_id]" id="seentics_website_id" type="text" class="regular-text code" value="<?php echo esc_attr( $o['website_id'] ); ?>" placeholder="123e4567-e89b-12d3-a456-426614174000" autocomplete="off" />
						<p class="description"><?php esc_html_e( 'In Seentics: Settings → Tracking.', 'seentics' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Administrators', 'seentics' ); ?></th>
					<td>
						<label><input name="seentics_options[track_admins]" type="checkbox" value="1" <?php checked( $o['track_admins'], 1 ); ?> /> <?php esc_html_e( 'Track visits by logged-in administrators', 'seentics' ); ?></label>
						<p class="description"><?php esc_html_e( 'Off by default, so your own browsing does not count as traffic.', 'seentics' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'WooCommerce', 'seentics' ); ?></th>
					<td>
						<?php if ( function_exists( 'WC' ) ) : ?>
							<label><input name="seentics_options[woocommerce]" type="checkbox" value="1" <?php checked( $o['woocommerce'], 1 ); ?> /> <?php esc_html_e( 'Report purchases, product views, add to cart and checkout', 'seentics' ); ?></label>
							<p class="description"><?php esc_html_e( 'Purchases appear under Revenue; the other events can be used in funnels and goals. Refunds are not reported yet.', 'seentics' ); ?></p>
						<?php else : ?>
							<input name="seentics_options[woocommerce]" type="hidden" value="<?php echo esc_attr( (int) $o['woocommerce'] ); ?>" />
							<p class="description"><?php esc_html_e( 'WooCommerce is not active on this site.', 'seentics' ); ?></p>
						<?php endif; ?>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="seentics_script_url"><?php esc_html_e( 'Tracker script URL', 'seentics' ); ?></label></th>
					<td>
						<input name="seentics_options[script_url]" id="seentics_script_url" type="url" class="regular-text code" value="<?php echo esc_attr( $o['script_url'] ); ?>" />
						<p class="description"><?php esc_html_e( 'Only change this if you host Seentics yourself. Must be https.', 'seentics' ); ?></p>
					</td>
				</tr>
			</table>
			<?php submit_button(); ?>
		</form>
	</div>
	<?php
}
