=== Seentics ===
Contributors: seentics
Tags: analytics, woocommerce, session recording, heatmaps, revenue
Requires at least: 5.8
Tested up to: 6.6
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Adds the Seentics tracker to your site and reports WooCommerce purchases, product views, add to cart and checkout.

== Description ==

Paste your website ID and Seentics starts collecting pageviews, session recordings and heatmaps. With WooCommerce, the plugin also reports:

* `purchase` on the order confirmation page: order total, currency, order number, line items and whether the customer is new or returning. Shown under Revenue, with source and campaign attribution.
* `view_item` on product pages.
* `add_to_cart`.
* `begin_checkout` on the checkout page.

Those events can be used in Seentics funnels and goals.

= External service =

This plugin loads a script from Seentics (`https://seentics.com/trackers/seentics.min.js` by default, or the URL you set if you host Seentics yourself) and the script sends visit data to Seentics. See https://seentics.com/privacy.

= Not included yet =

Refunds are not reported. Record them from Seentics if you need revenue net of refunds.

== Installation ==

1. Upload the `seentics` folder to `/wp-content/plugins/`, or install the zip from Plugins → Add New → Upload.
2. Activate it.
3. Settings → Seentics: paste the website ID from Seentics (Settings → Tracking) and save.

== Frequently Asked Questions ==

= Does it count my own visits? =

Not when you are logged in as an administrator, unless you turn that on.

= Does it work with page caching? =

Yes. The tracker is a static script tag. Purchase events are printed on the order confirmation page, which WooCommerce does not cache.

== Changelog ==

= 1.0.0 =
* First release.
