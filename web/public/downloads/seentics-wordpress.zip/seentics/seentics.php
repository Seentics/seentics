<?php
/**
 * Plugin Name:       Seentics
 * Plugin URI:        https://seentics.com
 * Description:       Adds the Seentics tracker to your site and, with WooCommerce, reports purchases, product views, add-to-cart and checkout for revenue reports and funnels.
 * Version:           1.0.0
 * Requires at least: 5.8
 * Requires PHP:      7.4
 * Author:            Seentics
 * Author URI:        https://seentics.com
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       seentics
 */

defined( 'ABSPATH' ) || exit;

define( 'SEENTICS_VERSION', '1.0.0' );
define( 'SEENTICS_DEFAULT_SCRIPT_URL', 'https://seentics.com/trackers/seentics.min.js' );
define( 'SEENTICS_DIR', plugin_dir_path( __FILE__ ) );

require_once SEENTICS_DIR . 'includes/settings.php';
require_once SEENTICS_DIR . 'includes/tracker.php';
require_once SEENTICS_DIR . 'includes/woocommerce.php';

add_filter(
	'plugin_action_links_' . plugin_basename( __FILE__ ),
	function ( $links ) {
		array_unshift( $links, '<a href="' . esc_url( admin_url( 'options-general.php?page=seentics' ) ) . '">' . esc_html__( 'Settings', 'seentics' ) . '</a>' );
		return $links;
	}
);
