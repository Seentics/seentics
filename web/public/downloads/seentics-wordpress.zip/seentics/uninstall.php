<?php
/**
 * Removes the plugin's saved settings when it is deleted from the Plugins screen.
 */

defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

delete_option( 'seentics_options' );
